<!-- Nav tabs -->
 <div class="confor" id="apply-formID">
 <h2 class="text-center">Apply Now</h2>
            <form action="" class="apply-form"> 
                <div class="inpubox">
                    <input type="text" required="required">
                    <span>Full Name</span>
                </div>
                <div class="inpubox">
                    <input type="text" required="required">
                    <span>Email</span>
                </div>
                <div class="inpubox">
                    <input type="text" required="required">
                    <span>Phone</span>
                </div>
                <div class="inpubox">
                <input type="text" required="required">
                    <span>Select Course</span>
                    <!-- <select name="" id="" class="select-boxs">
                        <option value="BBA">B.B.A</option>
                        <option value="BCA">B.C.A</option>
                        <option value="MBA">M.B.A</option>
                        <option value="Engineering(B.E)">Engineering(B.E)</option>
                        <option value="Engineering(M.E)">Engineering(M.E)</option>
                    </select> -->
                </div>
                <div class="inpubox">
                  <button type="submit" class="btn submit-btn">Submit</button>
                </div>
            </form>
        </div>

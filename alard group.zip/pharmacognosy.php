<!DOCTYPE html>
<html lang="en">

<head>
    <title>Alard Education Institute</title>
    <!-- META TAGS -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description"
        content="Education master is one of the best educational html template, it's suitable for all education websites like university,college,school,online education,tution center,distance education,computer education">
    <meta name="keyword"
        content="education html template, university template, college template, school template, online education template, tution center template">
    <!-- FAV ICON(BROWSER TAB ICON) -->
    <link rel="shortcut icon" href="myimg/favicon.png" type="image/x-icon">
    <!-- GOOGLE FONT -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700%7CJosefin+Sans:600,700"
        rel="stylesheet">
    <!-- FONTAWESOME ICONS -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link href="css/owl.carousel.min.css" rel="stylesheet">
    <!-- ALL CSS FILES -->
    <link href="css/materialize.css" rel="stylesheet">
    <link href="css/bootstrap.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet" />
    <link href="css/rani.css" rel="stylesheet" />
    <!-- RESPONSIVE.CSS ONLY FOR MOBILE AND TABLET VIEWS -->
    <link href="css/style-mob.css" rel="stylesheet" />

</head>

<body>


    <?php include 'header.php'; ?>

    <section class="mysvg">
        <div class="head-2" id="rules">
            <div class="container">
                <div class="head-2-inn head-2-inn-padd-top">
                    <h1>College Of Pharmacognosy</h1>
                </div>
            </div>
        </div>
        <?php include 'anim.svg'; ?>
    </section>

    <section>
        <div class="ab-es">
            <div class="container pad-bot-70">

                <div class="row mt-40">
                    <p> Pharmacognosy is the study of medicinal drugs derived from plants or other natural sources. The American Society of Pharmacognosy defines pharmacognosy as “the study of the physical, chemical, biochemical and biological properties of drugs, drug substances or potential drugs or drug substances of natural origin as well as the search for new drugs from natural sources”. It is also defined as the study of crude drugs.</p>
                </div>

                <div class="row mt-40">
                    <div class="col-md-12 col-xs-12">
                        <div class="tab" role="tabpanel">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#Section1" aria-controls="home"
                                        role="tab" data-toggle="tab">Eligibility</a></li>
                                <li role="presentation"><a href="#Section2" aria-controls="profile" role="tab"
                                        data-toggle="tab">Duration</a></li>
                                <li role="presentation"><a href="#Section3" aria-controls="program" role="tab"
                                        data-toggle="tab">Program Fee</a></li>
                                <li role="presentation"><a href="#Section4" aria-controls="process" role="tab"
                                        data-toggle="tab">Selection Process</a></li>
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content tab">
                                <div role="tabpanel" class="tab-pane fade in active" id="Section1">
                                    <p>Passed Bachelor of Pharmacy  with 50% and GPAT Entrance qualified Score</p>
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="Section2">
                                    <p>2 Years</p>
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="Section3">
                                    <div class="row">
                                        <div class="table-responsive table-desi">
                                            <table class="table table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th>Program Fee</th>
                                                        <th>(Rs.In Lacs)</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="table-inner">
                                                    <tr>
                                                        <td>1st Year Non Sponsored Semester</td>
                                                        <td>0.82</td>
                                                    </tr>
                                                    <tr>
                                                        <td>1st Year Sponsored Semester Fee</td>
                                                        <td>Management Decision</td>
                                                    </tr>

                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="Section4">
                                    <p>English Language Test</p>
                                    <p>Subject Based Written Test</p>
                                    <p>Personal Interview</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div><br>
                <a href="ad-form.php" class="admission-btn ">Application For Addmisson</a>
                </div><br>
                <div class="row mt-40">

                    <div class="col-md-12 col-xs-12">
                        <div class="tab" role="tabpanel">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#Section5" aria-controls="home"
                                        role="tab" data-toggle="tab">1 Year</a></li>
                                <li role="presentation"><a href="#Section6" aria-controls="profile" role="tab"
                                        data-toggle="tab">2 Year</a></li>
                                <!-- <li role="presentation"><a href="#Section7" aria-controls="program" role="tab"
                                        data-toggle="tab">3 Year</a></li>
                                <li role="presentation"><a href="#Section8" aria-controls="program" role="tab"
                                        data-toggle="tab">4 Year</a></li> -->
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content tab">
                                <div role="tabpanel" class="tab-pane fade in active" id="Section5">
                                    <div class="col-row">
                                        <div class="col-md-6">
                                            <h3>Semester 1</h3>
                                            <div class="ad-detail-list">
                                                <ul>
                                                    <li>Seminar – I [Non Teaching Credit Courses]</li>
                                                    <li>Advanced Pharmacology-I [Core Courses]</li>
                                                    <li>Cellular and Molecular Pharmacology [Core Courses]</li>
                                                    <li>Modern Pharmaceutical Analytical Techniques [Core Courses]</li>                                                  
                                                    <li>Pharmacological and Toxicological Screening Methods- I [Core Courses]</li>
                                                    <li>Pharmacology Practical I [Core Courses]</li>
                                                    <li>Advanced Communication [Communication Skills]</li>
                                                    <li>Self Development and Interpersonal Skills [Behavioural Science]</li>
                                                    <li>Foreign Business Language</li>
                                                    <li>Open Elective Courses</li>
                                                    <li>Outdoor Activity Based Courses</li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <h3>Semester 2</h3>
                                            <div class="ad-detail-list">
                                                <ul>
                                                    <li>Assignment [Non Teaching Credit Courses]</li>
                                                    <li>Advanced Pharmacology II [Core Courses]
                                                    </li>
                                                    <li>Advanced Organic Chemistry II [Core Courses]</li>
                                                    <li>Clinical Research and Pharmacovigilance [Core Courses]</li>
                                                    <li>Pharmacological and Toxicological Screening Methods-II [Core Courses]</li>
                                                    <li>Pharmacology Practical II [Core Courses]</li>
                                                    <li>Principles of Drug Discovery [Core Courses]
                                                    </li>
                                                    <li>Communication for Employment [Communication Skills]</li>
                                                    <li>Conflict Resolution and Management [Behavioural Science]</li>
                                                    <li>Foreign Business Language</li>
                                                    <li>Open Elective Courses</li>
                                                    <li>Outdoor Activity Based Courses</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane fade" id="Section6">
                                    <div class="col-row">
                                        <div class="col-md-6">
                                            <h3>Semester 3</h3>
                                            <div class="ad-detail-list">
                                                <ul>
                                                    <li>Journal Club – I [Non Teaching Credit Courses]</li>
                                                    <li>Proposal Presentation [Non Teaching Credit Courses]</li>
                                                    <li>Research Work – I [Non Teaching Credit Courses]</li>
                                                    <li>Natural Products and Herbal Medicines [Domain Elective Courses]</li>
                                                    <li>Research Methodology and Biostatistics- [Core Courses]</li>
                                                    <li>Professional Communication Skills [Communication Skills]
                                                    </li>
                                                    <li>Professional Competencies and Career Development [Behavioural Science]</li>                                                   
                                                    <li>Foreign Business Language</li>
                                                    <li>Open Elective Courses</li>
                                                    <li>Outdoor Activity Based Courses</li>
                                                </ul>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <h3>Semester 4</h3>
                                            <div class="ad-detail-list">
                                                <ul>
                                                    <li>Major Project [Non Teaching Credit Courses]</li>
                                                    <li>Drug Discovery and Clinical Development of Drugs [Core Courses]</li>
                                                   <li>Foreign Business Language</li>
                                                    <li>Open Elective Courses</li>
                                                    <li>Outdoor Activity Based Courses</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                           
                            
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>

    <!--SECTION START-->
    <?php include 'footer.php'; ?>

    <!--Import jQuery before materialize.js-->
    <script src="js/main.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/materialize.min.js"></script>
    <script src="js/custom.js"></script>
    <script>
        $(document).ready(function () {
            $("div.bhoechie-tab-menu>div.list-group>a").click(function (e) {
                e.preventDefault();
                $(this).siblings('a.active').removeClass("active");
                $(this).addClass("active");
                var index = $(this).index();
                $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
                $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
            });
        });
    </script>
</body>

</html>